"""matplotlib 中文与统一样式。"""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


def setup() -> None:
    plt.rcParams.update({
        "font.sans-serif": [
            "Noto Sans CJK SC", "Source Han Sans SC", "WenQuanYi Zen Hei",
            "PingFang SC", "Microsoft YaHei", "SimHei", "DejaVu Sans",
        ],
        "axes.unicode_minus": False,
        "figure.dpi": 150,
        "savefig.dpi": 200,
        "savefig.bbox": "tight",
        "font.size": 10,
        "axes.grid": True,
        "grid.alpha": 0.3,
    })
